showdown.subParser('makeMarkdown.hr', function () {
  'use strict';

  return '---';
});
